<?php

        require("class.user2.php");
        require("class.pdofactory.php");

        print "Running...<br />";

        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $objUser = new User($objPDO);
        $objUser2 = new User($objPDO);
        $objUser3 = new User($objPDO);

        //user 1 ----------------------
        $objUser->setFirstName("Cristian");
        $objUser->setLastName("Ramirez");
        $objUser->setDateAccountCreated(date("Y-m-d"));

        print "First name is " . $objUser->getFirstName() . "<br />";
        print "Last name is " . $objUser->getLastName() . "<br />";

        print "Saving...<br />";

        $objUser->Save();
        print"<br>";

        print "ID in database is " . $objUser->getID() . "<br />";

        //user 2 -----------------------
        $objUser2->setFirstName("Carmelo");
        $objUser2->setLastName("Ibañez");
        $objUser2->setDateAccountCreated(date("Y-m-d"));

        print "First name is " . $objUser2->getFirstName() . "<br />";
        print "Last name is " . $objUser2->getLastName() . "<br />";

        print "Saving...";
        $objUser2->Save();

        print "ID in database is " . $objUser2->getID() . "<br />";
        print"<br>";

        //user 3 -----------------------------
        $objUser3->setFirstName("Pegaso");
        $objUser3->setLastName("Benito");
        $objUser3->setDateAccountCreated(date("Y-m-d"));

        print "First name is " . $objUser3->getFirstName() . "<br />";
        print "Last name is " . $objUser3->getLastName() . "<br />";

        print "Saving...<br />";
        print"<br>";

        $objUser3->Save();

        print "ID in database is " . $objUser3->getID() . "<br />";
        print"<br>";
        
        //delete  -----------------------------------------------
        $objUser5 = new User($objPDO , $objUser3->getID());
        $objUser5->MarkForDeletion();
        unset($objUser5);

        //update ---------------------------------------------
        print"update user";
        $objUser2->setFirstName("update");
        $objUser2->Save();

        //mostramos datos
        print "First name is " . $objUser2->getFirstName() . "<br /> ";
        print "Last name is " . $objUser2->getLastName() . "<br />";
        print "ID in database is " . $objUser2->getID() . "<br /><br />";



?>
