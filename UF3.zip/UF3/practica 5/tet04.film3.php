<?php
        
        print "fkljs";

        require_once("class.pdofactory.php");
        print "2";
        require_once("abstract.databoundobject.php");
        print "3";
        require_once("class.film.php");
        print "4";

        print "Running...<br />";

        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          
        $obsjfilm = new Film($objPDO);

        //setea los datos
        $obsjfilm->setTitle("Alex")->setDescription("Comedia")->setReleaseYear(2000)->setLanguageId(1)->setRentalDuration(2)->setRentalRate(5)->setLength(2)->setReplacementCost(2.3)->setRating("G")->setLastUpdate(date("Y-m-d"))->setSpecialFeatures("{Mision}")->setFulltext("Texto sin mas");

        $obsjfilm->Save();

        echo "coorecto insert";
        echo"<br>";

        //Actualitzem dades
        echo "<h3>Actualitzem l'objecte 44</h3>";
        $obsjfilm->setTitle('Fede');
   
        //Guardem l'actualitzacio
        $obsjfilm->save();
        print "Actualització feta<br />";
        echo "coorecto update";
        echo"<br>";


        //Eliminem l'objecte
        echo "Elimino el objeto ";
        echo"<br>";
        /*Elimino el usuario 44  */ 
        $obsjfilm = new film($objPDO , $obsjfilm->getID());
        $obsjfilm->MarkForDeletion();
        unset($obsjfilm);

        echo "eliminado correctamente";
        

                   

 ?>       
