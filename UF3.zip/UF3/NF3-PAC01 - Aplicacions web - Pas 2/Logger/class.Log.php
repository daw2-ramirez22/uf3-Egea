<?php

include_once("abstract.databoundobject.php");

class Log extends DataBoundObject {

protected $Msg;

protected function DefineTableName() {
        return('logdate');
}

protected function DefineRelationMap() {
        return(array(
                "message" => "Message",
                "loglevel" => "Loglevel",
                "logdate" => "Loglevel",
                "module" => "Module"));
}
}

?>
