<?php

include_once("class.Logger.php");

class ftpLoggerBackend extends Logger{
  public function __construct() {
      
    //This is pseudo code that fetches a hash of configuration information
    //Implementation of this is left to the reader, but should hopefully
    //be quite straight-forward.
    $cfg = new Config();
  }
}
?>
