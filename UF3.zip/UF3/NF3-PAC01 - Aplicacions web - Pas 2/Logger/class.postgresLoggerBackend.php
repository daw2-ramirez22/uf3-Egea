<?php

include_once("class.Logger.php");
include_once("class.Log.php");
include_once("class.pdofactory.php");

class postgresLoggerBackend extends Logger {
    public function __construct($urlData) {

        $dbName = ltrim($urlData["path"],'/');
      
        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


        echo "Postgres Log";
      }

      public function LogearCosas()
      {
        $objAddress = new Log($objPDO);

        $objAddress->setMessage("mensageCristianlo13")
                     ->Save();

        $objAddress1 = new Log($objPDO);

        $objAddress1->setMessage("mensageCristianlog2")
                    ->Save();

        $objAddress2 = new Log($objPDO);

        $objAddress2->setMessage("mensageCristianlog3")
                      ->Save();
      }
}
?>
