<?php

include_once("class.Logger.php");

class fileLoggerBackend extends Logger {
  //Note: private constructor.  Class uses the singleton pattern
  public function __construct() {
    
    //This is pseudo code that fetches a hash of configuration information
    //Implementation of this is left to the reader, but should hopefully
    //be quite straight-forward.
    $this -> cfg = new Config();

    $this -> CargarFichero();
  }


  public function CargarFichero(){
	  

    /* If the config establishes a level, use that level,
       otherwise, default to INFO
    */
    $this->logLevel = $this -> cfg->getConfigLevel();
	$this->logFile = $this -> cfg->getConfigFile();
	echo "file: ".$this->logFile."<br>";

    //We must specify a log file in the config
    if(!(isset($this->logFile) && strlen($this->logFile)) ) {
      throw new Exception('No log file path was specified ' .
                          'in the system configuration.');
    }
 
    //Open a handle to the log file.  Suppress PHP error messages.
    //We'll deal with those ourselves by throwing an exception.
    $this->confile = @fopen($this->logFile, 'a+');
    
    if(!is_resource($this->confile)) {
      throw new Exception("The specified log file ".$this -> logFile.
                   'could not be opened or created for ' .
                   'writing.  Check file permissions.');
    }
  }

  public function LogearCosas(){
    fwrite($this->confile, "mensageCristianlog1\r\n");
    fwrite($this->confile, "mensageCristianlog2\r\n");
    fwrite($this->confile, "mensageCristianlog3\r\n");
  }
}
?>
