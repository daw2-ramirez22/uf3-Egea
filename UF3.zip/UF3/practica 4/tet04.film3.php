<?php
        require_once("class.pdofactory.php");
        require_once("abstract.databoundobject.php");
        require_once("class.user3.php");
        require_once("class.film.php");
        require_once("class.customer.php");
        require_once("class.address.php");

        print "Running...<br />";

        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          
        $obsjfilm = new Film($objPDO);
        $obsjfilm1 = new Film($objPDO, 11);

        //setea los datos
        $obsjfilm->setTitle("Torrente");
        $obsjfilm->setDescription("Comedia");
        $obsjfilm->setReleaseYear(2000);
        $obsjfilm->setLanguageId(1);
        $obsjfilm->setRentalDuration(2);
        $obsjfilm->setRentalRate(5);
        $obsjfilm->setLength(2);
        $obsjfilm->setReplacementCost(2.3);
        $obsjfilm->setRating("G");
        $obsjfilm->setLastUpdate(date("Y-m-d"));
        $obsjfilm->setSpecialFeatures("{Mision}");
        $obsjfilm->setFulltext("Texto sin mas");




        //hace un get de los metodos firstname y lastname
        print "Titulo" . $obsjfilm->getTitle() . "<br />";
        print "Description" . $obsjfilm->getDescription() . "<br />";
        print "ReleaseYear" . $obsjfilm->getReleaseYear() . "<br />";
        print "LanguageId" . $obsjfilm->getLanguageId() . "<br />";
        print "RentalDuration" . $obsjfilm->getRentalDuration() . "<br />";
        print "RentalRate" . $obsjfilm->getRentalRate() . "<br />";
        print "Length" . $obsjfilm->getLength() . "<br />";
        print "ReplacementCost" . $obsjfilm->getReplacementCost() . "<br />";
        print "Rating" . $obsjfilm->getRating() . "<br />";
        print "LastUpdate" . $obsjfilm->getLastUpdate() . "<br />";
        print "SpecialFeatures" . $obsjfilm->getSpecialFeatures() . "<br />";
        print "Fulltext" . $obsjfilm->getFulltext() . "<br />";




        print "Saving...<br />";

        //lo guarda
        $obsjfilm->Save();

        //me da el id con el que se guarda
        $id = $obsjfilm->getId();
        print "ID in database is " . $id . "<br />";

        print "Destroying object...<br />";
        unset($objfilm);

        print "Recreating object from ID $id<br />";
        $obsjfilm = new Film($objPDO, $id);

        //saco por pantalla del buscador los datos
        print "Titulo" . $obsjfilm->getTitle() . "<br />";
        print "Description" . $obsjfilm->getDescription() . "<br />";
        print "ReleaseYear" . $obsjfilm->getReleaseYear() . "<br />";
        print "LanguageId" . $obsjfilm->getLanguageId() . "<br />";
        print "RentalDuration" . $obsjfilm->getRentalDuration() . "<br />";
        print "RentalRate" . $obsjfilm->getRentalRate() . "<br />";
        print "Length" . $obsjfilm->getLength() . "<br />";
        print "ReplacementCost" . $obsjfilm->getReplacementCost() . "<br />";
        print "Rating" . $obsjfilm->getRating() . "<br />";
        print "LastUpdate" . $obsjfilm->getLastUpdate() . "<br />";
        print "SpecialFeatures" . $obsjfilm->getSpecialFeatures() . "<br />";
        print "Fulltext" . $obsjfilm->getFulltext() . "<br />";

 

        print "Committing a change.... film <br/>";
        $obsjfilm->setTitle("Torrente");
        $obsjfilm->setDescription("Comedia");
        $obsjfilm->setReleaseYear(2000);
        $obsjfilm->setLanguageId(1);
        $obsjfilm->setRentalDuration(2);
        $obsjfilm->setRentalRate(5);
        $obsjfilm->setLength(2);
        $obsjfilm->setReplacementCost(2.3);
        $obsjfilm->setRating("G");
        $obsjfilm->setLastUpdate(date("Y-m-d"));
        $obsjfilm->setFulltext("Texto sin mas");


        print "Saving...<br />";
        $obsjfilm->Save();

        //guardem la id de l'usuari i la mostrem
        $id = $obsjfilm->getID();
        print "ID in database is " . $id . "<br />";

        print "Destroying object...<br />";
        unset($obsjfilm);

        //Creem l'usuari a partir de l'id i el guardem amb aquest
        print "Recreating object from ID $id<br />";
        $obsjfilm = new Film($objPDO, $id);

        //Actualitzem el cognom de Nowicki per Nowickcow setejant
        print "Committing a change.... Daniel will become TORRENTE, 
         MARVEL will become Trujillo<br/>";

         $obsjfilm->setTitle("MARVEL");
         $obsjfilm->setDescription("SCFI");

        //Mostrem els cognoms
        print "The First name of customer is " . $obsjfilm->getTitle() . "<br />";
        print "The Last name of customer is " . $obsjfilm->getDescription() . "<br />";
        
        
        //Actualitzem les dades
        print "Saving...<br />";
        $obsjfilm->Save();
        
        //borrar datos
        $obsjfilm1->MarkForDeletion();
        
 ?>       
