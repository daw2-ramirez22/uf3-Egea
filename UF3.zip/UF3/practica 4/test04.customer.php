<?php
        //Cridem als diferents arxius
        require_once("class.pdofactory.php");
        require_once("abstract.databoundobject.php");
        require_once("class.customer.php");

        print "Running...<br />";

        //fem la conexio
        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        //Creem un usuari
        $objCusto = new Customer($objPDO);
        $objCusto1 =new Customer($objPDO, 2);

        //Seteamos el nom, cognom y data de creacio
        $objCusto->setStoreId(1);
        $objCusto->setFirstName("Daniel");
        $objCusto->setLastName("Catillo");
        $objCusto->setAddressId(1);

        //Mostra el nom y el cognom
        print "The First name of customer is " . $objCusto->getFirstName() . "<br />";
        print "The Last name of customer is " . $objCusto->getLastName() . "<br />";

        print "Saving...<br />";

        //Guardem a la bd
        $objCusto->Save();

        //guardem la id de l'usuari i la mostrem
        $id = $objCusto->getID();
        print "ID in database is " . $id . "<br />";

        //eliminem l'usuari
        print "Destroying object...<br />";
        unset($objCusto);

        //Creem l'usuari a partir de l'id i el guardem amb aquest
        print "Recreating object from ID $id<br />";
        $objCusto = new Customer($objPDO, $id);

        //Mostrem els cognoms
        print "The First name of customer is " . $objCusto->getFirstName() . "<br />";
        print "The Last name of customer is " . $objCusto->getLastName() . "<br />";

        //Actualitzem el nom de Steve per Steven setejant
        //Actualitzem el cognom de Nowicki per Nowickcow setejant
        print "Committing a change.... Daniel will become Cristian, 
               Castillo will become Trujillo<br/>";
        $objCusto->setFirstName("Cristian");
        $objCusto->setLastName("Ramriez");

        //Mostrem els cognoms
        print "The First name of customer is " . $objCusto->getFirstName() . "<br />";
        print "The Last name of customer is " . $objCusto->getLastName() . "<br />";


        //Actualitzem les dades
        print "Saving...<br />";
        $objCusto->Save();

        //borrar datos
        $objCusto1->MarkForDeletion();
?>
