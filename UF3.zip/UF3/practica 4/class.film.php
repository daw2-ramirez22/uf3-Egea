<?php


class Film extends DataBoundObject {

        protected $Film_id;
        protected $Title;
        protected $Description;
        protected $ReleaseYear;
        protected $LanguageId;
        protected $RentalDuration;
        protected $RentalRate;
        protected $Length;
        protected $ReplacementCost;
        protected $Rating;
        protected $LastUpdate;
        protected $SpecialFeatures;
        protected $Fulltext;

    

        protected function DefineTableName() {
                return("film");
        }

        protected function DefineRelationMap() {
                return(array(
                        "id" => "Id",
                        "title" => "Title",
                        "description" => "Description",
                        "release_year" => "ReleaseYear",
                        "language_id" => "LanguageId",
                        "rental_duration" => "RentalDuration",
                        "rental_rate" => "RentalRate",
                        "length" => "Length",
                        "replacement_cost" => "ReplacementCost",
                        "rating" => "Rating",
                        "last_update" => "LastUpdate",
                        "special_features" => "SpecialFeatures",
                        "fulltext" => "Fulltext"));
        }
}

?>