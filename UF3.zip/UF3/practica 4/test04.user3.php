<?php
        require_once("class.pdofactory.php");
        require_once("abstract.databoundobject.php");
        require_once("class.user3.php");
        require_once("class.film.php");
        require_once("class.customer.php");
        require_once("class.address.php");

        print "Running...<br />";

        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //crea el objeto de las calse
        
        $objUser = new User($objPDO);

        //setea los datos
        $objUser->setFirstName("Steve");
        $objUser->setLastName("Nowicki");
        $objUser->setDateAccountCreated(date("Y-m-d"));

        //hace un get de los metodos firstname y lastname
        print "First name is " . $objUser->getFirstName() . "<br />";
        print "Last name is " . $objUser->getLastName() . "<br />";

        print "Saving...<br />";

        //lo guarda
        $objUser->Save();

        //me da el id con el que se guarda
        $id = $objUser->getID();
        print "ID in database is " . $id . "<br />";
        print "Destroying object...<br />";
        unset($objUser);

        print "Recreating object from ID $id<br />";
        $objUser = new User($objPDO, $id);

        //saco por pantalla del buscador los datos
        print "First name is " . $objUser->getFirstName() . "<br />";
        print "Last name is " . $objUser->getLastName() . "<br />";

        print "Committing a change.... Steve will become Steven, 
               Nowicki will become Nowickcow<br/>";
        $objUser->setFirstName("Steven");
        $objUser->setLastName("Nowickcow");
        print "Saving...<br />";
        $objUser->Save();
       
    
        
 ?>       
