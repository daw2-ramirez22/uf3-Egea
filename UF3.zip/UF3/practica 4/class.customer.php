<?php

class Customer extends DataBoundObject{

    protected $ID;
    protected $StoreId;
    protected $FirstName;
    protected $LastName;
    protected $email;
    protected $AddressId;
    protected $Activebool;
    protected $CreateDate;
    protected $LastUpdate;
    protected $active;

    

    protected function DefineTableName() {
        return("customer");
    }

    protected function DefineRelationMap() {
        return(array(
            "id" => "ID",
            "store_id" =>"StoreId",
            "first_name" =>"FirstName",
            "last_name" =>"LastName",
            "email" =>"email",
            "address_id" =>"AddressId",
            "activebool" =>"Activebool",
            "create_date" =>"CreateDate",
            "last_update" =>"LastUpdate",
            "active" =>"active"));
    }


}
?>