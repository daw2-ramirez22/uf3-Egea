<?php
        require_once("class.pdofactory.php");
        require_once("abstract.databoundobject.php");
        require_once("class.film.php");


        print "Running...<br />";

        $strDSN = "pgsql:dbname=chaptersix;host=localhost;port=5432";
        $objPDO = PDOFactory::GetPDO($strDSN, "postgres", "alex",array());
        $objPDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          
        $obsjfilm = new Film($objPDO);

        //setea los datos
        $obsjfilm->setTitle("Alex")->setDescription("Comedia")->setReleaseYear(2000)->setLanguageId(1)->setRentalDuration(2)->setRentalRate(5)->setLength(2)->setReplacementCost(2.3)->setRating("G")->setLastUpdate(date("Y-m-d"))->setSpecialFeatures("{Mision}")->setFulltext("Texto sin mas");

        $obsjfilm->Save();

        echo "coorecto";
 ?>       
